# Sigil Engine V20 · Environment System

Adds a real subtle background/environment system:
- Deep Void
- Observatory
- Ghost Cathedral
- Living Archive
- Astral Ocean
- Living Ink
- Signal Grid
- Ritual Mix
- Dream Mix

New controls:
- Env intensity
- Env blur
- Env motion

Defaults are darker and more discreet so the drawing remains the protagonist.
