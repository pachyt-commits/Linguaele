# Sigil Engine V16.2 · Contrast Glow Fix

Fixes:
- Glow no longer eats the drawing.
- Fog is darker and less white.
- Memory and echo layers are darker.
- Added Contrast and Glow Cut controls.
- Added crisp structural pass for line readability.
- Reduced particle and landscape brightness.
