# Sigil Engine V12 · Anti-Mandala

Visual direction change:
- Breaks old-school mandala/kaleidoscope look.
- New modes: Organism, Flow Field, Fracture, Signal Body, Swarm, Free.
- Adds Asym and Depth controls.
- Symmetry is now imperfect, delayed, skewed, and organic.
- Aura no longer draws perfect rings.
- Processing templates are now less radial and more spatial/organic.

Keeps:
- Audio rhythmic mapping
- Motion
- Processing editor
- Brushes
- Presets
- PNG/WebM export
