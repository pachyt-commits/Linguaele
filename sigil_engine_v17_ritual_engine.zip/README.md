# Sigil Engine V17 · Ritual Engine

Adds:
- Ritual Mandala modes
- Cathedral Radial
- Orbital Bloom
- Sacred Signal
- Brush size control
- Cinematic color palettes
- Brush-specific glow behavior
- Lower overall glow / stronger structure
