# Sigil Engine V19 · Processing Studio

Adds:
- Processing Studio panel
- Processing layer in layer stack
- Run / Stop / Reset / Save / Load
- Templates: Ritual Geometry, Flow Fields, Cathedral Machine, Swarm Garden, Signal Organism, Ghost Trails
- Processing API: p.line, p.circle, p.rect, p.triangle, p.translate, p.rotate, p.noise, p.random
- Variables: audio, bass, mid, high, beat, motion, time, width, height, centerX, centerY
- Keyboard E toggles Processing Studio
