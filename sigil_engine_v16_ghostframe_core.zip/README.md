# Sigil Engine V16 · Ghostframe Core

Temporal Echo Engine, Ghost Layers, Haunt mode, delayed stroke ghosts, memory decay, playback ghosts.
