# Sigil Engine V11 · Rhythmic Mapping

Audio now modulates rhythm instead of spraying particles:
- Bass expands geometry/orbits.
- Mids deform lines and aura.
- Highs create shimmer and small CRT movement.
- Rhythm and Smooth controls added.
- Processing editor preserved.
