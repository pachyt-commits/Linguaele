# Sigil Engine V17.1 · Ritual Background

Adds:
- Giant atmospheric ritual mandala in background
- Broken symmetry
- Slow cathedral radial architecture
- Soft audio pulse
- Layered environmental aura

The mandala returns as environmental architecture instead of dominating the entire identity.
