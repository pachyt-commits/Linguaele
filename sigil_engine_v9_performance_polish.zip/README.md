# Sigil Engine V9 · Performance Polish

Adds:
- Apple Pencil / pointer pressure influence.
- Smoother brush feel with velocity memory.
- Freeze mode.
- Layer toggles: Aura / Particles / Processing / Glyph-only.
- Projector mode.
- Pinch gesture controls mutate.
- Two-finger tap/freeze gesture.
- Keeps V8: forms, brushes, audio, motion, Processing editor, presets, PNG/WebM export.

Shortcuts:
- E: editor
- F: freeze
- L: layer toggle
- P: projector
- Escape: exit ritual/projector
