# Sigil Engine V16.1 · Exposure Fix

Fixes:
- V16 was overexposing to white because memory/echo layers accumulated via screen blending.
- Lowered memory/echo defaults.
- Added darker decay and exposure limiter.
- Haunt mode is now subtler.
