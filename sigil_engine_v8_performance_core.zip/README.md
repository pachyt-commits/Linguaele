# Sigil Engine V8 · Performance Core

Includes:
- V7 form systems
- brush systems
- audio reactive
- motion capture
- Processing-style live editor
- presets
- ritual mode with exit
- PNG export
- 12-second WebM recording

Shortcuts:
- E: editor
- Escape: exit ritual

Run:
python -m http.server
