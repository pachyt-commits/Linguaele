# Sigil Engine V10 · Overdrive Processing

Adds:
- Stronger audio and motion response.
- Audio X, Motion X, Chaos controls.
- Bass/mid/high split.
- Processing editor restored and improved.
- Processing templates: Rings, Shockwave, Mesh, Glyph Rain.
- Save and clear Processing sketches.
- Stronger particles, aura, signal distortion, brush width and color response.
