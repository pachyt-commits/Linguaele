# Sigil Engine V14 · Spatial Depth

Adds:
- Camera drift
- Fog volumes
- Spatial pseudo-3D echoes
- Parallax landscapes
- Spatial particle trails
- Depth/Drift/Fog controls

The visuals now feel like drifting audiovisual environments instead of flat generators.
